# 字体图标

> 字体图标<span style="color:red">展示的是图标，本质是字体。</span>

![image-20230315142039471](.\assets\520643a0820b5c43a330022629290faff9662611.png)

iconfont-阿里巴巴矢量图标库

https://www.iconfont.cn/

iconfont 支持上传 SVG 矢量图

示例：

```html
<link rel="stylesheet" href="iconfont/iconfont.css">

<i class="iconfont icon-star"></i>
```

![字体图标](./assets/ef3ba59b7e312bd41d3f0d79485481087860d4b7.png)